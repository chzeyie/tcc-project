<?php
// Include database connection
include 'db_connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Water Sales Management</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Water Sales Management</h1>
    
    <form id="addItemForm" action="add_item.php" method="POST">
        <input type="text" name="item_name" placeholder="Enter water product name" required>
        <button type="submit">Add Item</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Item Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $result = $conn->query("SELECT * FROM items");

            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>";
                echo "<form action='edit_item.php' method='POST' style='display:inline;'>";
                echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
                echo "<input type='text' name='new_name' placeholder='Edit name' required>";
                echo "<button type='submit'>Edit</button>";
                echo "</form> ";

                echo "<form action='delete_item.php' method='POST' style='display:inline;'>";
                echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
                echo "<button type='submit'>Delete</button>";
                echo "</form>";
                echo "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
